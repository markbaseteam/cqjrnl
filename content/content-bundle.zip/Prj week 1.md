---
quickshare-date: 22 02 2023 19:10:42
quickshare-url: "https://noteshare.space/note/clefa1d84249601pjuwhwvxkp#1Z/s+H/hJepJGNkEHgDHHGT5lkMX97wryyA+krY8cVg"
---
project brainstorming, what can we do for prj

-server
-client
-router/firewall - pfsense - 2 network ports

3 computers from nmit, + switch, cables, harddrives

-attacker - laptop

-network switch
-cables

have fallbacks to be able to reset 3 computers if they get too infected.

**corp policies around cybersec**

setting up a mock network at home to then perform various attacks on, researching attacks and preventation methods and performing them to show what it can do or what can be lost. could do like before/after - so without any security, protocols, what can happen if a network is attacked.
then after security has been put in place, with the same attacks.
i feel like this is more something that i would develop more as it goes along, especially with testing my own limits of what i can do. still an outline is necessary for proposal.
-   your proposal should be clear and concise (3-4 pages maximum) you should address your proposal to the BIT Project Committee as a formal memo style document
-   the goal of your project and how you are going to achieve that goal needs to be VERY clearly stated
-   make sure that what you are proposing is possible in the time and with the skills you have, i.e. that it is realistic
-   to include ALL the costs that you think you might need.

---

cannot do this subject anymore, as its networking related and project must be in the area of my stupid major, software development. looking into some possible topics that i could turn into a project.

>application security products that find vulnerabilities in code
A cybersecurity analyst detects cyber threats and then implements changes to protect an organization.

> To conduct software security testing, it is necessary to establish a baseline so that any future changes can be measured and compared to the original baseline. To accomplish this, it is necessary to develop an attack surface map of the battlefield. It is necessary to define the points of entry into the software, such as the use of HTTP headers or user display forms and the use of run-time arguments because these are attack vectors that an attacker can leverage. In addition, aside from the ingress and egress of data and the numerous methods that a program can employ for input, processing, and output, it is beneficial for the developer to ask, “How will the attacker view the code?” which may provide additional insight to the developer in code review for security purposes.
Another tool that can assist developers in mitigating security issues in developed code is the use of vulnerability scanning tools such as Abby Scan, AppScan, and many others listed on the OWASP website (OWASP, n.d.). Once an attack surface map has been created, it is necessary to assign a priority ranking to high-risk areas to identify and address them. Security-conscious programming requires the use of a configuration management process, the establishment of a baseline for program security, and the use of an attack surface map to prioritize the risks that must be addressed.

>building a web app to break such simple encryption; later on, move on to complex concepts. Your software interface should have a space for the input text, a drop option to choose the ‘Shift,’ and a space for the output text, which will be the cipher decoded text. The example is shown below:

![](https://www.upgrad.com/blog/wp-content/uploads/2020/10/Untitled-4.jpg)

http://practicalcryptography.com/ciphers/caesar-cipher/

>creating your own antivirus. To start the projects, first, you need to define the methods of protection that you’re going to develop, and select platforms that your software will support. For instance, macro-protection for Windows can be written in VBScript

>Building a packet sniffer is an opportunity to practice networking and programming skills. You can create a simple packet sniffer in Python with a socket module. After configuring your socket module to capture packets from the network, you’ll write Python scripts to extract those captured packets.

>Data recovery skills are vital to cyber incident response, as malware can corrupt, destroy, or manipulate data. [Ransomware attacks](https://www.springboard.com/blog/cybersecurity/common-cybersecurity-terms/) encrypt a victim’s data and demand payment for decrypting the files.
Outline a ransomware data recovery procedure to practice data retrieval skills. Focus on restoring the affected systems from a backup. Next, build a plan for using data recovery tools to extract corrupted or deleted data from storage devices.

### Documentation

Robust documentation is necessary to communicate cybersecurity protocols and build effective cybersecurity policies. When conducting risk assessments and audits, cybersecurity professionals must document their methodologies, findings, analyses, and recommendations. Consistent, straightforward documentation of incident response procedures is also necessary to mount a successful cyber incident response.

### Coding 

Programming skills are necessary to detect vulnerabilities, conduct malware analysis, automate security tasks, and remediate cybersecurity risks. Coding is a particularly important skill for mid-level and upper-level cybersecurity professionals, and helps advanced professionals understand system architecture. Coding skills are also central to cryptography. 

### Cryptography

Cybersecurity professionals use cryptography to secure data and communications. In the event of a data breach, this encryption ensures the security of an organization’s private data. To perform cryptography, you’ll need to be able to design algorithms, ciphers, and other security measures that encode and protect sensitive data.

### Network Oversight

Network security encompasses hardware and software protocols. Cybersecurity professionals use networking skills to protect networked systems and ensure reliable, authorized access to applications and data that facilitate key business operations.

### Testing and Identifying Threats

Threat identification is a critical component of any risk management strategy. Common cybersecurity threats include malware, phishing, and ransomware. Penetration tests and vulnerability assessments are used to identify the cybersecurity risks that these threats pose to an organization’s infrastructure. You’ll need testing and threat identification skills to execute security audits and make recommendations for vulnerability remediation

>**Hacking a Computer Not Connected to the Internet.**
This will scare your classmates, if they don't already know about it, but it's a fact that even when a computer is not connected to the internet, it can transmit data through heat, vibrations, sound, and light. For this project, you will research how a hacker can steal information by means of a smartphone from an "air-gapped" computer not connected to the internet.

-   Anomaly detection, intrusion and its prevention
-   Stalking threats and instance responding
-   Detecting or mitigating compromising indicators
-   Intelligence analyzing factors of ethical, privacy and  legal
-   Research on relevant Geopolitical Cyber security
-   Cyber security data analytics
-   Data demonstration, fusion and semantic modeling
-   Forecasting models on cyber-attacks and control measures
-   Intelligence in cyber threat
-   Models that concern Deception and Improbability in cyber-attack acknowledgement
-   Visualizing intelligence analysis and investigation techniques
-   Cybercrime monetization and orchestration and automating security

>practical application: scripted deployment of production instances w/ monitoring/detection suite and caldera on kali, automated operations for applicable abilities and scripted analysis of events/logs/alerts to validate and improve detection reliability.

>more literature review/academic: study of the correlation between TTPs identified in attacks and coverage capabilities of popular endpoint/enterprise protection solutions. For bonus points, consider (1) disaggregating the data into key demographic groups like industry/sector, geography, size, etc. and (2) correlating to risk assessment considerations (e.g., which solution results in the greatest impact to risk? which solutions reduce risk the most per dollar spent for a given hypothetical situation?)

>using machine learning to identify ransomware threat actors
-   Word doc attachment -> opens a new process -> makes network connections
>A benign word doc normally shouldn’t be spawning off other processes that make network connections. So they train their model on safe/malicious scenarios, standard ML stuff.

>signature based detection and automating a script to do more. Find a manual labor job ids does and try to automate it.

>You can implement your own SIEM on your home network using SecOnion Linux distro. All you have to do is tap your network and push some device logs to Kibana and make some dashboards so you can monitor the traffic being logged
Well you can develop 400 hours of analytics and visualizations to compliment the setup and you can also perform vulnerability assessments using another device with openVAS installed. You can also install a MS 2019 server for free and configure your end points on the network in Active directory as well / push security policies out as long as the devices you are using have win 10 pro

>writing your own honeypot

>comparison of 2 SIEMs, their architecture, detection methods , and ease of use.
set one up on a vm and the other on physical environment with a hub. Then generate normal traffic and started following the cyber kill chain to generate malicious traffic. Also tested zero-days, phishing, shells, etc...


### Further ideas to research more
- contribute to open source project related to infosec, ir writing a plugin or developing on/improving/making a solution to a problem the application has
- fuzzing, writing your own fuzer or getting one, then using it with some kind of open source stuff and submitting a bug report if abnormal behaviour results.
