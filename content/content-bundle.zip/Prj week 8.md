This week I got back in Nelson and finished the tutorial series from last week.
I found that it wasn't really ideal towards what I was trying to accomplished, because they were targetting a certain rust library and the fuzzing program the tutor wrote in this series was really simple ( think like one code block worth of code ) he also used tools such as libafl, which I have already covered in a previous week, and it was really quite hard to follow along with because the tutor talked with a thick european accent which I had to have subtitles on to understand so overall it was a poor couple of weeks work doing this.

After that, I started writing the code for the fuzzer itself because I had to get a move on.

I used these two projects as a reference point for a working rust fuzzer
- https://epi052.gitlab.io/notes-to-self/blog/2021-11-01-fuzzing-101-with-libafl/

- https://github.com/AFLplusplus/LibAFL/blob/main/fuzzers/forkserver_simple/src/main.rs

The first one was extremely helpful and guided me a lot during putting together this project. The author went indepth into his explanations of what the different components do, how to use them, and how to put them all together.