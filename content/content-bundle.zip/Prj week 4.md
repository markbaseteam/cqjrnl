This week was spent research into things iI could actually do for my fuzzing in this project

- cve vuln database, what sort of fuzzing could trigger a vulnerability.
- we can fuzz input - validation - including attack vectors like sqls and xss
- file parsers - images, videos, audio - see how the application handles the files
- encryption and decryption algorithms? worth looking into a bit more see if its interesting
- APIs. find defects or vulns. everytime i see the word API i forget what it means, idk why i always forget. its like a thing that plugs data into third party stuff to extract certain data from the original thing right.
- network protocols: fuzzing can be used to test network protocols, such as TCP/IP, HTTP, FTP, and SMTP, for vulnerabilities. by sending malformed packets to the protocol's interface, you can find buffer overflows, denial of service (DoS) vulnerabilities, and other security issues. might also be interesting

Was hoping to find a program to target in this weeks stuff but I couldnt find much time to spend on it outside of reading/watching info about fuzzing. things take a suprisingly longer amount of time than you'd imagine.

I also have to prepare for my seminar upcoming next week so taken more time for that this week.

command line programs