Presentation 1 (near the start of the semester):

-   The problem you're working on
-   How you are approaching it
-   Challenges you're facing

Each presentation should be 3-5 minutes, followed by 2 minutes of questions.

Each presentation is marked out of 5:

-   3 marks for the presentation
-   1 mark for asking a relevant question
-   1 mark for providing a relevant answer to a question.

- find a good slide presentation program for linux

The problem i'm working on right now is how to take the next steps after working through a basic fuzzer that performs random inputs, then triggers a crash when a string of letters is detected together at the start of that input.
I have to get to the next point of being able to write something more complicated, to get into fuzzing something like network protocols, api calls, file parsing, or encryption algos.

**Network protocols**
	- this would invovle :

**API**
	- this would involve:

**File parsing**
	- this would involve:

**Encryption**
	- this would involve:

Alternatively, I could use more than one of these approaches, in more than one program. This has yet to be determined and needs more research.

Challenges i'm facing currently are lack of focus and attention span lol. It's hard to sit down and work at this for longer than a couple of hours opposed to in my first couple of years where I could be working on something for like 8 hours straight up.
Also finding relevant starting points for complete beginners since this is something I have only just started to learn about. A lot of documentation and tools out there use fairly technical speak assuming people are somewhat experienced and understand what theyre doing. I need resources that can help me understand what i'm doing as I go. To this end, the documentation on the basic fuzzer I first learnt was the most helpful that i've found so far, as it explained every step of the way, but it's shortcoming was that it didn't cover anything beyond the most simple technique.