
## Goals

- [x]  Download and set up afl++ fuzzing tools
- [x] <sub>fix laptop bc i upgraded distro and it broke gnome shell</sub>
- [x]  work through documentation on their website
- [x]  work through tutorials on their website
- [x]  research into what programs you can test on
- [x]  pick target
- [x]  do you know how to use the afl fuzzer?

*Incomplete goals will be carried on into Week 4.

## Notes
run command: `cargo run`
build fuzzers from their folders: `cargo build --release`

### Crates
LibAFL is composed of different crates. A crate is an individual library in Rust's Cargo build system, that you can use by adding it to your project's `Cargo.toml`

### Corpus
set of inputs for the fuzzing target

### Components
- **State**
	- a container of data that evolves while the fuzzing proceeds. includes the corpus of inputs, current RNG, poetntial metadata of test cases and run. performs actions on individual inputs, taken from the corpus.
		- *Mutatational stage* executes the harness several times in a row, with mutated inputs each time
- **Event Manager**
	- handles events like adding more test cases to the corpus during fuzzing. displays info about events using an instance of Monitor
- **Fuzzer**
	- contains actions that alter the state. uses a Scheduler to serve testcases to the fuzzer
- **Executor**
	- runs the program under test. runs the harness function. takes references to harness, state, event manager
- **Generator**
	- generates a string of printable bytes
- **Observer**
	- records information about the properties of the run and feeds the fuzzer. uses a map to keep track of covered elements. goes in the executor
- **Feedback**
	- part of the state that rates the input to see if it's of interest to add it to the corpus. maintains the cumulative state of information.
		- *Objective feedback* is another kind of feedback which decides if an input is a 'solution', and saves it to solutions (./crashes) other than corpus, when the input has been rated as interesting

## Prog
I can't figure out how to make the other fuzzers run when i tried to compile and run a few that I chose at random out of the fuzzers that were included. I read the individual documentation on them however none of the code works or even the `-help` text that comes along with it. In the frida fuzzers, it tells me the usage but trying tons of options just all gives errors.
![[Pasted image 20230309171114.png]]
Instructions from the readme for frida

![[Pasted image 20230309171152.png]]
using `cargo run` instead because the full command ./frida... turned up red, there was no directory named that

![[Pasted image 20230309171337.png]]

![[Pasted image 20230309170932.png]]

`cargo run` by itself did nothing but display the help text, wanting parameters?

![[Pasted image 20230309171431.png]]

Figured out finally that you have to cd to target/release or target/debug to actually find the fuzzing script that works. then

`./frida_fuzzer -F LLVMFuzzerTestOneInput -H ./libpng-harness.so -l ./libpng-harness.so`

to run it. but it finishes with 0 executions, so have to figure out more of the arguments it takes to point it to the right path. The harness I see in my directory is just called harness.cc so trying with that arg instead.
I cant do it after trying a lot of options, and the process takes longer than a minute each time i test something out, so its not worth it for me to continue trying with this one.
![[Pasted image 20230309173013.png]]

Anyway, I completed the baby fuzzer and it ran successfully using the random input generator just by itself. The tutorial was not very specific in some parts, and copying in the code snippets often gave errors when trying to run it. I had to work these out for myself as compiler error text wasn't too helpful either. the code needed to be in a specific order and the tutorial also didn't tell you that, but it was able to run and generate crash logs in the folder too. The screenshots had a bit more debug log into printed out on the screen, and mine doesn't, but as far as I can see there is no mention of that in the tutorial either.

![[Pasted image 20230309173303.png]]
The one I wrote generates a bunch of random string characters and iterates through them. When the string matches 'abc', it crashes. The lowest number of executions I saw it take was 300, while the highest was 17,000 until it found the right combo.

![[Pasted image 20230309173630.png]]
3 different crash logs of the string that caused the panic.

The documentation beyond this point is too advanced and very hard to understand with a skim read. I need way way more basic instructions than what it's saying here, but at least doing the baby one has been successful.
Before picking a target, I need to research a lot more into different beginner tutorials to find out what other things than just inputting random numbers and crashing if a combination is reached - that they can do. Specifically on working with program runtimes, or file formats.