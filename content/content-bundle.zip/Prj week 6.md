## Building last week's task in LibAfl with Rust

This week i'm applying the knowledge and skills I learnt last week with fuzzing the xpdf program in afl++, to building a fuzzer with libafl's custom component library using rust.

the good thing about rust is that it'll just run in terminal rather than needing a code editor program, which is really handy. obviously you can use any notepad app to create the .rs files and write that code, but running commands works anywhere in terminal.
to set up a folder as a rust workspace it's super easy, you need to make a `cargo.toml` file in any folder, as a little template to mark it as a workspace folder. here's a default i found:
```
[workspace]

members = [
    "<rust-project-names-listed-here>",
    "<these-will-be-your-diff-folders>"
]

[profile.release]
lto = true
codegen-units = 1
opt-level = 3
debug = true
```

(dont need to include the < > around the names)
-   `lto=true` :: perform link-time optimizations across all crates within the dependency graph
-   `codegen-units=1` :: controls how many “code generation units” a crate will be split into; higher codegen-units **MAY** produce slower code (max value 256)
-   `opt-level=3` :: controls the level of optimizations; 3 == “all optimizations”
-   `debug=true` :: controls the amount of debug information included in the compiled binary; true == “full debug info”

then in terminal you can write `cargo new project-name` and that'll create another folder inside that workspace and populate it with the files you'll need, which includes .git stuff so its compatible with github.

tried to make a build.rs script to compile xpdf with afl clang again, failed cause couldnt get the directorys and stuff right "error couldnt configure, no file or directory was found". some bullshit. paths were correct. compiling manually rather than needing a complicated script for something that i can do within 10 seconds.

Going back through the tutorial you did a couple weeks ago making that example baby fuzzer will be helpful to refresh memory and understand what rust components, functions, and parts the fuzzer needs to have in its main src code, so read thru that again. and also open your main src file and read the notes in the code.

Going through tutorial at academy.fuzzinglabs.com - "introduction to rust fuzzing"