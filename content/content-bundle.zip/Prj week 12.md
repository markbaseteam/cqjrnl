First things first, I was advised to try out my corrupted file with a newer version of xpdf, since the vulnerability existed in an older version, I compiled the latest one, not without an hour or so of troubleshooting to get it to compile correctly of course.
Testing out the same file within gdb on the newer install resulted in no segmentation faults, but a large amount of syntax errors instead. See screenshot below.

![[Pasted image 20230509144825.png]]
So reading that, it seems to have been fixed.

This week i've started writing up my project report. on that note there isnt really anything much more i can write in my journal.