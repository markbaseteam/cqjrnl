I was finishing off my other classes assignment for the start of the week, then continued on with writing my fuzzer.

Still following the projects, they did not work out of the box when writing my own so I had to do a lot of working out errors and finding out the correct ways to format things.
Also referring to the libafl documentation here:
https://docs.rs/libafl/latest/libafl/
This was typed up the week after I should have written it so thats why it lacks detail compared to some of the earlier posts.
Sorry theres no screenshots but I can say over the course of writing the fuzzer from scratch to having a working program, I had about 5 minutes realtime of nonstop scrolling worth of errors in the terminal that I had to figure out and fix.

At the end of this, I finally had a program that would build without errors. I shut my laptop for the week immediately after.