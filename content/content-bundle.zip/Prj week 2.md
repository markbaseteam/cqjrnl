# Notes
Metasploit frameworks have modules that can be used for fuzzing, can look at writing one for use within the toolset
https://www.offensive-security.com/metasploit-unleashed/writing-simple-fuzzer/

or not, cause the codes pretty much already there written. but its a good point to review their code and read explanation of what it does. could look at writing a custom one for use in msf. their libraries are good to use for stuff like that.

* <mark class="blue">see rex text</mark>
  
https://github.com/rapid7/metasploit-framework/blob/master/lib/rex.rb

https://www.youtube.com/watch?v=BrDujogxYSk&
https://www.youtube.com/user/gamozolabs/videos
video tutorial and fuzzing streams. ik you hate vids but sometimes its good to listen to ppl explain shit

start by programming to test out mutations and get outputs rather than straight up going for a target. see how well it can perform mutating some input. improve speeds by looking at scheduling the inputs for mutation.

two main components, mutations and execution engine
when picking a target try for ones that are built on older code so it has a higher chance or crashing or being buggy, this is what we want, to actually have some results to observe, rather than testing against something well-written that never breaks no matter how much you throw at it.

main function -> setup phase and then fuzzing loop
the loop is the part which will be executing shitloads of times so only code vital to what it needs to do should go in there.
inside the loop we write code for mutating the data, and running the target.

when mutating, start with data that is actually valid and mutate it from there- rather than something random
python has bit flipping? start with: flip a single bit at a time to mutate.
change one letter/number/byte to another. be aware of what the input considers valid (does it only take alphabetical characters?)
may need to write code to set the inputs up and feed them correctly to the target "harnessing"

feedback must be gathered from every input (see AFL's execution feedback)

https://github.com/grimm-co/killerbeez
https://github.com/AFLplusplus/LibAFL
projects that have made fuzzing framework with swappable components

record speeds to observe and cut down on any overheads.

test on svg files. older programs. inkscape?